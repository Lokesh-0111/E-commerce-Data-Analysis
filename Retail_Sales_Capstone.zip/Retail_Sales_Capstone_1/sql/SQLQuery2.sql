--Business Questions 
--1. What is the total revenue generated in the last 12 months? 
select ROUND(sum(total_amount),2) as total_revenue_last_12_months
from cleaned_salesdata
where order_date >= DATEADD(MONTH, -12, GETDATE())

--2. Which are the top 5 best-selling products by quantity? 
SELECT TOP 5 pr.product_name,sum(sa.quantity ) as total_quantity_sold
from cleaned_productstable as pr join Cleaned_salesdata as sa
on pr.product_id = sa.product_id
group by pr.product_name
order by total_quantity_sold DESC

--3. How many customers are from each region?
SELECT region, count(customer_id) as total_customers
from customer_cleaned_data
group by region
order by total_customers

--4. Which store has the highest profit in the past year? 
SELECT TOP 1 st.store_name, sum(sa.net_sales - sa.total_amount) as profit
from Cleaned_storedata as st join Cleaned_salesdata as sa
on st.store_id = sa.store_id
where sa.order_date >= DATEADD(MONTH, -12, GETDATE())
GROUP BY st.store_name
order by profit DESC

--5. What is the return rate by product category? 
SELECT 
    p.category,
    SUM(CASE WHEN r.order_id IS NOT NULL 
             THEN s.quantity ELSE 0 END) * 100.0/ SUM(s.quantity) AS return_rate_percentage
FROM Cleaned_salesdata s
JOIN cleaned_productstable p
    ON s.product_id = p.product_id
LEFT JOIN Cleaned_returns_table r
    ON s.order_id = r.order_id
GROUP BY p.category
ORDER BY return_rate_percentage DESC;

--6. What is the average revenue per customer by age group?
SELECT c.age_group, avg(s.total_amount) as average_revenue_per_customer
FROM customer_cleaned_data as c
JOIN Cleaned_salesdata as s
ON c.customer_id = s.customer_id
GROUP BY c.age_group
ORDER BY average_revenue_per_customer DESC

--7. Which sales channel (Online vs In-Store) is more profitable on average?
SELECT s.sales_channel, avg(p.profit_perunit) as profiable_on_avg
FROM Cleaned_salesdata as s join cleaned_productstable as p
on p.product_id = s.product_id
GROUP BY s.sales_channel
ORDER BY profiable_on_avg DESC

--8. How has monthly profit changed over the last 2 years by region? 
SELECT c.region, FORMAT(order_date, 'yyyy-MM') AS Month, sum(s.net_sales) as monthly_profit
FROM customer_cleaned_data as c join Cleaned_salesdata as s
ON c.customer_id = s.customer_id
WHERE s.order_date >= DATEADD(YEAR, -2, GETDATE())
GROUP BY FORMAT(order_date, 'yyyy-MM'), c.region
ORDER BY Month, c.region

--9. Identify the top 3 products with the highest return rate in each category.
SELECT TOP 3 p.product_name,p.category,SUM(CASE WHEN r.order_id IS NOT NULL 
             THEN s.quantity ELSE 0 END) * 100.0/ SUM(s.quantity) AS return_rate
FROM cleaned_productstable AS p JOIN Cleaned_salesdata as s
ON p.product_id = s.product_id
LEFT JOIN Cleaned_returns_table as r
ON r.order_id = s.order_id
GROUP BY p.category,p.product_name
ORDER BY return_rate DESC

--10. Which 5 customers have contributed the most to total profit, and what is their tenure with the company? 
SELECT TOP 5
    CONCAT(c.first_name,' ',c.last_name) as customer_name,
    SUM(s.net_sales) AS total_profit,
    DATEDIFF(YEAR, MIN(s.order_date), GETDATE()) AS tenure_years
FROM Cleaned_salesdata s
JOIN customer_cleaned_data c
    ON s.customer_id = c.customer_id
GROUP BY CONCAT(c.first_name,' ',c.last_name)
ORDER BY total_profit DESC;